# FbCMD4j

Facebook CLI client. For educational purposes only.

## Instalación

TODO: Agregar proceso de instalación.

## Uso

TODO: Agregar instrucciones de uso

## Créditos

TODO: Agregar autor(es)

## Licencia

TODO: Agregar Licencia
